package app;

import model.*;
import service.FacadeService;
import service.InvalidInputException;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        FacadeService facade = FacadeService.getInstance();
        Scanner scanner = new Scanner(System.in);

        facade.loadUsersFromFiles();

        boolean running = true;
        while (running) {
            System.out.println("\n==== MEDTRACK MENU ====");
            System.out.println("1. Register as new patient");
            System.out.println("2. Book an appointment");
            System.out.println("3. View my appointments");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    System.out.print("Enter your name: ");
                    String name = scanner.nextLine().trim();
                    System.out.print("Enter your insurance provider: ");
                    String insurance = scanner.nextLine().trim();
                    String newId = "P" + System.currentTimeMillis() % 10000;
                    Patient newPatient = new Patient(newId, name, insurance);
                    facade.registerUser(newPatient);
                    System.out.println("✅ Registered successfully! Your patient ID: " + newId);
                    break;

                case "2":
                    System.out.print("Enter your patient ID: ");
                    String pid = scanner.nextLine().trim();
                    User foundUser = facade.findUserById(pid);
                    if (!(foundUser instanceof Patient)) {
                        System.out.println("❌ Invalid patient ID.");
                        break;
                    }

                    // Show doctors
                    System.out.println("\nAvailable Doctors:");
                    for (User u : facade.getAllUsers()) {
                        if (u instanceof Doctor) {
                            System.out.println("- ID: " + u.getId() + " | " + u.getName() + " (" + u.getRoleInfo() + ")");
                        }
                    }

                    System.out.print("Enter doctor ID to book with: ");
                    String did = scanner.nextLine().trim();
                    User dUser = facade.findUserById(did);
                    if (!(dUser instanceof Doctor)) {
                        System.out.println("❌ Invalid doctor ID.");
                        break;
                    }

                    System.out.print("Enter date (YYYY-MM-DD): ");
                    String date = scanner.nextLine().trim();
                    System.out.print("Enter time (HH:MM): ");
                    String time = scanner.nextLine().trim();

                    try {
                        Appointment appt = facade.bookAppointment((Patient) foundUser, (Doctor) dUser, date, time);
                        System.out.println("✅ Appointment booked! Confirmation code: " + appt.getConfirmationCode());
                    } catch (InvalidInputException e) {
                        System.err.println("❌ " + e.getMessage());
                        System.err.println("ℹ️  Details: " + e.getInvalidInput());
                    }
                    break;

                case "3":
                    System.out.print("Enter your patient ID: ");
                    String viewId = scanner.nextLine().trim();

                    User viewUser = facade.findUserById(viewId);

                    if (viewUser == null || !(viewUser instanceof Patient)) {
                        System.err.println("⚠️ User with ID '" + viewId + "' not found.");
                        System.err.println("❌ Invalid patient ID.");
                        break;
                    }

                    Patient viewPatient = (Patient) viewUser;

                    // 🟥 Load appointments from file before viewing
                    facade.loadAppointmentsFromFile(viewPatient);

                    List<Appointment> appointments = viewPatient.getAppointments();
                    if (appointments.isEmpty()) {
                        System.out.println("📭 No appointments found.");
                    } else {
                        System.out.println("📅 Your Appointments:");
                        for (Appointment a : appointments) {
                            System.out.println("- " + a.getDate() + " " + a.getTime()
                                    + " with Doctor ID " + a.getDoctorId()
                                    + " (Code: " + a.getConfirmationCode() + ")");
                        }
                    }
                    break;

                case "4":
                    System.out.println("👋 Exiting MEDTRACK. Goodbye!");
                    running = false;
                    break;

                default:
                    System.out.println("❌ Invalid option. Try again.");
            }
        }

        scanner.close();
    }
}
