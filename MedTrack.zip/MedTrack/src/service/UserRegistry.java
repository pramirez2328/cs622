package service;

import model.Doctor;
import model.Patient;
import model.User;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class UserRegistry {
    private final List<User> users;

    public UserRegistry() {
        users = new ArrayList<>();
    }

    // Register a new user (Doctor or Patient)
    public void registerUser(User user) {
        users.add(user);
    }

    // Find a user by ID
    public User findUserById(String id) {
        for (User user : users) {
            if (user.getId().equals(id)) {
                return user;
            }
        }
        System.out.println("⚠️ User with ID '" + id + "' not found.");
        return null;
    }

    // 🟥 Value Added: Retrieve all users (used to load appointments or list doctors)
    public List<User> getAllUsers() {
        return users;
    }

    public void loadPatientsFromFile(String path) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(path));
            for (String line : lines) {
                String[] parts = line.split("\\|");
                if (parts.length == 3) {
                    String id = parts[0].trim();
                    String name = parts[1].trim();
                    String insurance = parts[2].trim();
                    Patient p = new Patient(id, name, insurance);
                    registerUser(p);
                }
            }
        } catch (IOException e) {
            System.err.println("❌ Could not load patients.txt: " + e.getMessage());
        }
    }

    public void loadDoctorsFromFile(String path) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(path));
            for (String line : lines) {
                String[] parts = line.split("\\|");
                if (parts.length == 3) {
                    String id = parts[0].trim();
                    String name = parts[1].trim();
                    String specialty = parts[2].trim();
                    Doctor d = new Doctor(id, name, specialty);
                    registerUser(d);
                }
            }
        } catch (IOException e) {
            System.err.println("❌ Could not load doctors: " + e.getMessage());
        }
    }

}
