package service;

import model.Appointment;
import model.Doctor;
import model.Patient;
import model.User;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class AppointmentManager {

    public boolean checkAvailability(Doctor doctor, String date, String time) {
        return doctor.isAvailable(date, time);
    }

    public Appointment bookAppointment(Patient patient, Doctor doctor, String date, String time) {
        if (patient == null) {
            throw new InvalidInputException("Patient is null", "null");
        }
        if (doctor == null) {
            throw new InvalidInputException("Doctor is null", "null");
        }
        if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
            throw new InvalidInputException("Invalid date format (expected YYYY-MM-DD)", date);
        }
        if (!time.matches("\\d{2}:\\d{2}")) {
            throw new InvalidInputException("Invalid time format (expected HH:MM)", time);
        }

        if (!doctor.isAvailable(date, time)) {
            throw new InvalidInputException("Doctor is already booked at " + date + " " + time,
                    doctor.getName() + " | " + date + " " + time);
        }

        Appointment appointment = new Appointment(
                patient.getId(), doctor.getId(), date, time
        );

        doctor.addAppointment(appointment);
        patient.addAppointment(appointment);

        try (FileWriter writer = new FileWriter("appointments.txt", true)) {
            writer.write(appointment.getConfirmationCode() + " | " +
                    patient.getName() + " | " +
                    doctor.getName() + " | " +
                    date + " " + time + "\n");
        } catch (IOException e) {
            System.err.println("Error saving appointment to file: " + e.getMessage());
        }

        return appointment;
    }

    // 🟥 Value Added: Load only the appointments for the given user (Doctor or Patient)
    public void loadAppointmentsFromFile(Patient patient) {
        boolean warned = false;
        try {
            List<String> lines = Files.readAllLines(Paths.get("appointments.txt"));
            for (String line : lines) {
                String[] tokens = line.split("\\|");
                if (tokens.length < 5) {
                    if (!warned) {
                        System.err.println("⚠️ Skipped malformed line:");
                        warned = true;
                    }
                    continue;
                }

                String fullCode = tokens[0].trim(); // APT-P3001-D1001-20250612-1200
                String[] parts = fullCode.split("-");
                if (parts.length < 5) continue; // extra safety

                String patientId = parts[1].trim();  // Extracted patient ID
                String doctorId = parts[2].trim();   // Extracted doctor ID

                String dateRaw = parts[3].trim();
                String timeRaw = parts[4].trim();
                String formattedDate = dateRaw.substring(0, 4) + "-" + dateRaw.substring(4, 6) + "-" + dateRaw.substring(6);
                String formattedTime = timeRaw.substring(0, 2) + ":" + timeRaw.substring(2);

                // 🟩 Improved debugging with delimiters
                System.out.println("Expected patient ID: [" + patient.getId() + "]");
                System.out.println("Parsed patient ID from file: [" + patientId + "]");

                if (patient.getId().equals(patientId)) {
                    Appointment a = new Appointment(patientId, doctorId, formattedDate, formattedTime);
                    patient.addAppointment(a);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading appointments: " + e.getMessage());
        }
    }
}
