package service;

import model.Appointment;
import model.Doctor;
import model.Patient;
import model.User;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * 🟥 FacadeService: Provides a single entry point for appointment-related operations.
 * Unifies access to UserRegistry and AppointmentManager, hiding internal structure.
 */
public class FacadeService {

    // Singleton instance
    private static final FacadeService instance = new FacadeService();

    private final UserRegistry userRegistry;
    private final AppointmentManager appointmentManager;

    private FacadeService() {
        this.userRegistry = new UserRegistry();
        this.appointmentManager = new AppointmentManager();
    }

    public static FacadeService getInstance() {
        return instance;
    }

    // 🟥 Register any user (Doctor or Patient)
    public void registerUser(User user) {
        if (user instanceof Patient patient) {
            try (FileWriter writer = new FileWriter("patients.txt", true)) {
                writer.write(patient.getId() + " | " + patient.getName() + " | " + patient.getInsuranceProvider() + "\n");
            } catch (IOException e) {
                System.err.println("❌ Could not save patient to file: " + e.getMessage());
            }
        }

    }

    // 🟥 Find user by ID (returns null if not found)
    public User findUserById(String id) {
        return userRegistry.findUserById(id);
    }

    // 🟥 Return all registered users (for displaying doctors)
    public List<User> getAllUsers() {
        return userRegistry.getAllUsers();
    }

    // 🟥 Book an appointment through a unified access point
    public Appointment bookAppointment(Patient patient, Doctor doctor, String date, String time) {
        return appointmentManager.bookAppointment(patient, doctor, date, time);
    }

    // 🟥 Load all appointments for registered users at startup
    public void loadAppointmentsFromFile(Patient patient) {
        appointmentManager.loadAppointmentsFromFile(patient);
        System.out.println("✅ Loaded appointments for patient " + patient.getId());
    }


    // 🟥 Load appointments for a specific patient
    public void loadAppointmentsFor(Patient patient) {
        appointmentManager.loadAppointmentsFromFile(patient);
    }

    public void loadUsersFromFiles() {
        userRegistry.loadDoctorsFromFile("doctors.txt");
        userRegistry.loadPatientsFromFile("patients.txt");
    }

}
