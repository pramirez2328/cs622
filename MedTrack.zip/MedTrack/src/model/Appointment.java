package model;

public class Appointment {
    private final String patientId;
    private final String doctorId;
    private final String date;
    private final String time;
    private final String confirmationCode;

    public Appointment(String patientId, String doctorId, String date, String time) {
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.date = date;
        this.time = time;
        this.confirmationCode = generateConfirmationCode();
    }

    private String generateConfirmationCode() {
        return "APT-" + patientId + "-" + doctorId + "-" + date.replace("-", "")
                + "-" + time.replace(":", "");
    }

    public String getConfirmationCode() {
        return confirmationCode;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }
}
