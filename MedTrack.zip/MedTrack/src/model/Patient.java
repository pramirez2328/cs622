package model;

import java.util.ArrayList;
import java.util.List;

public class Patient extends User {
    private final String insuranceProvider;
    private final List<Appointment> appointments;

    public Patient(String id, String name, String insuranceProvider) {
        super(id, name);
        this.insuranceProvider = insuranceProvider;
        this.appointments = new ArrayList<>();
    }

    public String getInsuranceProvider() {
        return insuranceProvider;
    }

    public void addAppointment(Appointment appointment) {
        appointments.add(appointment);
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }

    public void printAppointments() {
        if (appointments.isEmpty()) {
            System.out.println("📭 No appointments found for " + name);
            return;
        }

        System.out.println("📅 Appointments for " + name + ":");
        for (Appointment a : appointments) {
            System.out.println(" - On " + a.getDate() + " at " + a.getTime() +
                    " with Doctor ID: " + a.getDoctorId() +
                    " [Confirmation Code: " + a.getConfirmationCode() + "]");
        }
    }

    @Override
    public String getRoleInfo() {
        return "Patient: " + name + " (ID: " + id + ")";
    }
}
