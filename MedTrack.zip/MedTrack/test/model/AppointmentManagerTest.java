package model;

import org.junit.jupiter.api.Test;
import service.AppointmentManager;
import service.InvalidInputException;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentManagerTest {

    @Test
    public void testBookAppointmentSuccessfully() {
        Patient patient = new Patient("P1001", "John Doe", "BlueCross");
        Doctor doctor = new Doctor("D2002", "Dr. Daniel Lee", "Pediatrics");
        AppointmentManager manager = new AppointmentManager();

        // Book the appointment
        Appointment apt = manager.bookAppointment(patient, doctor, "2025-05-10", "14:00");

        assertNotNull(apt, "Appointment should be booked");
        assertEquals("P1001", apt.getPatientId());
        assertEquals("D2002", apt.getDoctorId());
    }

    @Test
    public void testBookFailsIfDoctorUnavailable() {
        Patient patient = new Patient("P1002", "Jane Smith", "MediCare");

        // Create doctor and simulate already booked time
        Doctor doctor = new Doctor("D2003", "Busy Doctor", "Oncology");
        AppointmentManager manager = new AppointmentManager();

        // First appointment (fills the time slot)
        manager.bookAppointment(patient, doctor, "2025-06-01", "10:00");

        // Second appointment at same time — should fail
        InvalidInputException exception = assertThrows(
                InvalidInputException.class,
                () -> manager.bookAppointment(patient, doctor, "2025-06-01", "10:00")
        );

        assertTrue(exception.getMessage().contains("already booked"));
    }
}
