package model;

import org.junit.jupiter.api.Test;
import service.UserRegistry;

import static org.junit.jupiter.api.Assertions.*;

public class UserRegistryTest {

    @Test
    public void testRegisterAndFindUser() {
        UserRegistry registry = new UserRegistry();
        Patient p = new Patient("P1001", "John Doe", "BlueCross");

        registry.registerUser(p);
        User result = registry.findUserById("P1001");

        assertNotNull(result);
        assertEquals("John Doe", result.getName());
        assertInstanceOf(Patient.class, result);
    }

    @Test
    public void testFindUserNotFound() {
        UserRegistry registry = new UserRegistry();
        assertNull(registry.findUserById("UNKNOWN"));
    }
}

