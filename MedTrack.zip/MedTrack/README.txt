README - MEDTRACK: A Medical Appointment and Records Management System
Author: Pedro Ramirez
Course: CS622

----------------------------------
HOW TO RUN THE APPLICATION
----------------------------------

1. Open the project in IntelliJ IDEA.

2. Ensure you have JDK 17+ installed (Java 23 used during development).

3. Run the Main class located at:
   src/app/Main.java

This will:
- Register a sample patient and doctor
- Book an appointment
- Print confirmation output to the console

----------------------------------
RUNNING TESTS
----------------------------------

1. The test directory is located at:
   test/model/

2. Right-click on any test file (e.g., AppointmentManagerTest.java) and select:
   "Run <testName>"

3. Tests are written using JUnit 5 and include:
   - Registration and user lookup tests
   - Appointment booking and conflict tests
   - Confirmation code format validation

----------------------------------
PROJECT STRUCTURE
----------------------------------

src/
├── app/                 → Main entry point
├── model/               → Domain classes (User, Doctor, etc.)
├── service/             → Business logic (AppointmentManager, UserRegistry)

test/
└── model/               → Unit tests for services and models

----------------------------------
NOTES
----------------------------------

- No external libraries are used.
- All data is stored in-memory for simplicity.
- Value-added logic is annotated in code and explained in the submission document.

Project created by: Pedro Ramirez - 2025
